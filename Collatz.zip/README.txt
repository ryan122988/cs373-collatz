Course Name: cs373 Software Engineering
Unique:
First Name:Ryan 
Last Name:Kluck
EID:rrk357
CS Username:ryan1229
GitHub ID:ryan122988
GitHub Repository Name:cs373-collatz
Estimated number of hours:3
Actual number of hours:8
Comments:

I attest that I have written every line of code that I have submitted
and I take full responsibility for the origin of all the code submitted.
In particular, if any of the code was originally written in a previous
semester or another course I will so acknowledge via e-mail to the
grader.
